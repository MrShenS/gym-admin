<template>
    <div class="login-wrap">
        <div class="ms-login" v-if="show==2">
            <div class="ms-title">健身房后台管理系统注册</div>
            <el-form
                :model="registerParam"
                :rules="registerRules"
                ref="login"
                label-width="0px"
                class="ms-content"
            >
                <el-form-item prop="employeeName">
                    <el-input v-model="registerParam.employeeName" placeholder="用户名">
                        <el-button slot="prepend" icon="el-icon-lx-people"></el-button>
                    </el-input>
                </el-form-item>
                <el-form-item prop="employeePassword">
                    <el-input
                        type="employeePassword"
                        placeholder="员工密码"
                        v-model="registerParam.employeePassword"
                        @keyup.enter.native="submitForm()"
                    >
                        <el-button slot="prepend" icon="el-icon-lx-lock"></el-button>
                    </el-input>
                </el-form-item>
                <!-- <el-form-item prop="employeePost">
                    <el-input v-model="registerParam.employeePost" placeholder="员工职位">
                        <el-button slot="prepend" icon="el-icon-lx-crown"></el-button>
                    </el-input>
                </el-form-item>-->
                <el-form-item prop="employeePhone">
                    <el-input v-model="registerParam.employeePhone" placeholder="电话号">
                        <!--placeholder设置输入框内的默认值-->
                        <el-button slot="prepend" icon="el-icon-phone"></el-button>
                    </el-input>
                </el-form-item>
                <el-form-item prop="employeeEmail">
                    <el-input v-model="registerParam.employeeEmail" placeholder="邮箱">
                        <el-button slot="prepend" icon="el-icon-lx-mail"></el-button>
                    </el-input>
                </el-form-item>
                <div class="login-btn">
                    <el-button type="primary" @click="submitForm1()">注册</el-button>
                    <!-- <el-button type="primary" @click="submitForm()">注册</el-button> -->
                </div>
            </el-form>
        </div>
        <div class="ms-login" v-if="show==1">
            <div class="ms-title">健身房后台管理系统</div>
            <el-form
                :model="loginParam"
                :rules="loginRules"
                ref="login"
                label-width="0px"
                class="ms-content"
            >
                <el-form-item prop="username">
                    <el-input v-model="loginParam.username" placeholder="username">
                        <el-button slot="prepend" icon="el-icon-lx-people"></el-button>
                    </el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input
                        type="password"
                        placeholder="password"
                        v-model="loginParam.password"
                        @keyup.enter.native="submitForm()"
                    >
                        <el-button slot="prepend" icon="el-icon-lx-lock"></el-button>
                    </el-input>
                </el-form-item>
                <div class="login-btn">
                    <el-button type="primary" @click="submitForm()">登录</el-button>
                    <!-- <el-button type="primary" @click="submitForm()">注册</el-button> -->
                </div>
                <p class="login-tips">Tips : 用户名和密码随便填。</p>
                <el-button type="text" @click="toRegister()">注册</el-button>
            </el-form>
        </div>
    </div>
</template>

<script>
import https from '../../utils/https';
import qs from 'qs';
export default {
    data: function() {
        return {
            detail: {},
            show: 1,
            loginParam: {
                username: 'admin',
                password: '123123'
            },
            registerParam: {
                employeeName: 'admin',
                employeePassword: '123123',
                // employeePost: '',
                employeePhone: '',
                employeeEmail: ''
            },
            loginRules: {
                username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
                password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
            },
            registerRules: {
                employeeName: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
                employeePassword: [{ required: true, message: '请输入密码', trigger: 'blur' }],
                // employeePost: [{ required: true, message: '请输入职位', trigger: 'blur' }],
                employeePhone: [{ required: true, message: '请输入电话号', trigger: 'blur' }],
                employeeEmail: [{ required: true, message: '请输入邮箱', trigger: 'blur' }]
            }
        };
    },
    methods: {
        submitForm() {
            this.$refs.login.validate(valid => {
                if (valid) {
                    this.$message.success('登录成功');
                    localStorage.setItem('ms_username', this.loginParam.username);
                    this.$router.push('/');
                } else {
                    this.$message.error('请输入账号和密码');
                    console.log('error submit!!');
                    return false;
                }
            });
        },
        // 注册
        submitForm1() {
            let config = {
                employeeName: this.registerParam.employeeName,
                employeePassword: this.registerParam.employeePassword,
                employeePhone: this.registerParam.employeePhone,
                employeeEmail: this.registerParam.employeeEmail
            };
            console.log(this.registerParam, '参数');
            //访问后端接口
            // let params =JSON.stringify({
            //     'employeeName': this.registerParam.employeeName,
            //     'employeePassword': this.registerParam.employeePassword,
            //     'employeePhone': this.registerParam.employeePhone,
            //     'employeeEmail': this.registerParam.employeeEmail
            // });
            let params = {
                employeeName: this.registerParam.employeeName,
                employeePassword: this.registerParam.employeePassword,
                employeePhone: this.registerParam.employeePhone,
                employeeEmail: this.registerParam.employeeEmail
            };
            https
                .fetchPost('/GetCustomer', {
                    method: 'POST',
                    // headers: {
                    //     'Content-Type': 'application/x-www-form-urlencoded'
                    // },
                    body:  JSON.stringify(params)
                })
                .then(data => {
                    console.log(data.data);
                    this.detail = data.data;
                });
            //             let params = qs.stringify({
            //         certificationAccount: that.certificationAccount,
            //         balance: that.balance
            // })
            // that.a
            // let obj = qs.stringify({
            //         tab : JSON.stringify(config)
            //     });
            //     console.log(obj,"对象")
            //     https.fetchPost('/GetCustomer',params).then((data) => {
            //        console.log(data.data)
            //        this.detail=data.data
            //        console.log(this.detail,'detail')
            //         // console.log("this.base.tokenthis.base.token",this.base.token)
            //         // this.indexPost2(this.rres)
            //     }).catch(err=>{
            //             console.log(err)
            //         }
            //     )

            // this.show = 1;
            // this.$message.success('注册成功');
        },
        toRegister() {
            // this.$router.push('register')
            console.log(this.registerParam, '参数');
            this.show = 2;
            console.log(this.show, 321);
        }
    }
};
</script>

<style scoped>
.login-wrap {
    position: relative;
    width: 100%;
    height: 100%;
    background-image: url(../../assets/img/login-bg.jpg);
    background-size: 100%;
}
.ms-title {
    width: 100%;
    line-height: 50px;
    text-align: center;
    font-size: 20px;
    color: rgb(3, 0, 0);
    border-bottom: 1px solid #ddd;
}
.ms-login {
    position: absolute;
    left: 50%;
    top: 50%;
    width: 350px;
    margin: -190px 0 0 -175px;
    border-radius: 5px;
    background: rgba(255, 255, 255, 0.3);
    overflow: hidden;
}
.ms-content {
    padding: 30px 30px;
}
.login-btn {
    text-align: center;
}
.login-btn button {
    width: 100%;
    height: 36px;
    margin-bottom: 10px;
}
.login-tips {
    font-size: 12px;
    line-height: 30px;
    color: rgb(3, 0, 0);
}
</style>